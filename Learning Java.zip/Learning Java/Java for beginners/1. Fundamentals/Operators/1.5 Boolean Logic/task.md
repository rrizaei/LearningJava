## Exercise 1.5
***

You may need to get pencil and paper for this one.

#### What is the value stored in the variable *result*?

<div class="hint">
  Find the values inside parentheses first, then apply the operator between them.
</div>