public class BooleanCalculator
{
   public static void main(String[] args)
   {
      int a = 3, b = -4, c = 1;
      boolean t = true, f = false;
   }
}