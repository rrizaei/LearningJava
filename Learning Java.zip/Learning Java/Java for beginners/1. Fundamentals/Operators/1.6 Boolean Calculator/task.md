## Exercise 1.6
***

Again, you may need to use pencil and paper here.

#### Which of the following lines are equivalent to *true*? 

#### Note: Tick **ALL** those that are true, there may be more than one correct answer. 

<div class="hint">
  The operator precedence is the same as math: product and division are more important than addition and subtraction. When two operators have the same importance, compute them from left to right.
</div>

<div class="hint">
  Be careful with integer division!
</div>