public class classSyntax
{
   public static void main(String[] args)
   {

   }
}