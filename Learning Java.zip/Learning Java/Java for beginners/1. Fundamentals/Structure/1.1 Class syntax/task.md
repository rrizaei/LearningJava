## Exercise 1.1
***
#### Why is the previous code not working?

<div class="hint">
  Casing matters in Java.
</div>
