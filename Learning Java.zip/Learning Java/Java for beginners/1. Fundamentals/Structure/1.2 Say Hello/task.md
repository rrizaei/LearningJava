## Exercise 1.2
***
#### Print the following message on the console:
Hello! I am learning Java.<br>
I can print messages now.

#### Note: The code prints only two lines and the console cursor rests at the end of the dot of the second line.
<div class="hint">
  Remember to enclose messages using double quotes.
</div>
