//The class, as well as the file, is called ClassesInJava.
public class ClassesInJava
{
   //The main method; put it as-is in all your codes for now.
   public static void main(String[] args)
   {
      //This is a comment, ignored by Java.
      //Place statements here.
   }
}