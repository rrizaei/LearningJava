public class PrintingStatements {
   public static void main(String[] args) {
      System.out.println("This is the first message!");
      System.out.print("This is the second message.");
      System.out.print("This is the third message?");
      System.out.println("This is the 4th message.");
   }
}