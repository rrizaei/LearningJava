## Exercise 1.3
***
#### Complete the code to print the following message on the console:

*Dear Hisao, thank you for supporting our business.*<br>
*Cups of coffee bought: 1*<br>
*Cost of coffee: 99.9*<br>
*Your total is: $99.9.*<br>
*Tip is included? true*

<div class="hint">
  Do not forget to match the punctuation of the message as well!
</div>