public class SpeedCalculator
{
   public static void main(String[] args)
   {
      //Define two integer numbers.
      int kilometers = 213, hours = 6;
      //Define a floating point number.
      double speed;
      //Beware of integer division!
      speed = kilometers/(double)hours;
   }
}