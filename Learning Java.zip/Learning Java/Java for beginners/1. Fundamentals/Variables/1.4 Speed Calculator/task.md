## Exercise 1.4
***
You have stored the values of kilometers traveled in a car and the number of
hours it took to travel that far.
The variable speed contains the speed value in units of kilometers per hour.
#### Which of the following code segments yields the desired value? (There may be more than one possible answer, tick all those that are true.)