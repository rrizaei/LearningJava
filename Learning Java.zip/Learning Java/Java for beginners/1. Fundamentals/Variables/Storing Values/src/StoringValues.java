public class StoringValues
{
   public static void main(String[] args)
   {
      int hoursInADay = 24;
      double pi = 3.1416;
      boolean isTheSkyBlue;
      String languageName;

      isTheSkyBlue = true;
      languageName = "Java";

      System.out.println("Hours in a day: " + hoursInADay);
      System.out.println("Pi is close to " + pi);
      System.out.println("Is the sky blue?: " + isTheSkyBlue);
      System.out.print("The programming language we're learning is " + languageName);
   }
}