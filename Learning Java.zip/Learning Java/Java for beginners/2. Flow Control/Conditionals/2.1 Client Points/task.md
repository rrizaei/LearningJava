## Exercise 2.1

***

#### Set manually the values of *points* and *isVIPClient* such that the output shows that the customer may invest its points on 765 paper clips or a cutlery set.