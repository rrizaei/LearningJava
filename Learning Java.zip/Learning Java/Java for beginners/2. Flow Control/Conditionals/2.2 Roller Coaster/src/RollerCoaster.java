public class RollerCoaster
{
   public static void main(String[] args)
   {
      double height = 1.5; //in meters
      System.out.println("To enter the roller coaster, you must be at least 1.5 meters tall.");
      if (height >= 1.5)
         System.out.println("You may proceed.");
      else
         System.out.println("You may not ride it.");
   }
}