## Exercise 2.2

***

#### Set the condition.