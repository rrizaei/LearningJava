## Exercise 2.3

***

A programmer of a smart room system is asked to turn on the
fan whenever the temperature goes over 24 and the dehumidifier whenever
the humidity rises beyond 0.7 (70%).

However, if the smartMode option is turned on (*true*), only the fan may be activated.

#### In which of these situations the code does not work as intended?
