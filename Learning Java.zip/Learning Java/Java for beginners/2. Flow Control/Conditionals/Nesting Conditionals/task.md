### Nesting conditionals
***

Like a tree or a river, a code can have many branches.
The code selects one branch whenever multiple conditions are met at the same time.

Check the code to the left. Run it and make sure you understand why the output is that.

#### Note: When there's **only one** statement inside a conditional, you can omit the braces {}.
