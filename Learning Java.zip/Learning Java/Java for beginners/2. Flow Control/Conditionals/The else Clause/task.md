### The *else* statement
***

In some occasions, whenever a condition is not passed you want to execute an alternative block of code.
Instead of placing another *if* with the opposite condition, you may simply use the *else* keyword and
place inside braces the code you want to execute as an alternative to the original *if*.

The following code showcases this situation.