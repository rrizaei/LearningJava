## Exercise 2.4

***
#### What should be modified in the structure of the for loop to make it print odd numbers only?
##### More than one option allowed.