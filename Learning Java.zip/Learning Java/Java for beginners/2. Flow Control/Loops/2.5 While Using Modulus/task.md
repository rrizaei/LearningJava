## Exercise 2.5

***

#### Which value is stored  in the variable *count* as a result of executing the code segment?

##### Revise the modulus operator (%) at the end of Lesson 1 if needed.