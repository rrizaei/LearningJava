## Exercise 2.6

***

A freezer is designed to cool water only until it becomes ice at 0 degrees Celsius.

#### In line 21, for which one of these statements the break statement could be replaced so that in practice it has the same effect as the current code?