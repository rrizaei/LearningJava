## Exercise 2.7

***

The code is supposed to print the list of first 20 numbers (except 1) and state whether it's a prime number or not.

#### What should be placed in both placeholders, respectively, `break` or `continue`?

<div class="hint">
  There is more than one possible answer.
</div>
