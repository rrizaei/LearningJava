public class HundredthPrime
{
   public static void main(String[] args)
   {
      /* Make a code that displays the 100th prime number */
   }
}