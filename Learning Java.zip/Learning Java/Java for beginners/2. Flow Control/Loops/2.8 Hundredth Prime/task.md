## Exercise 2.8

***

#### Use the knowledge acquired so far to make a Java code that displays the hundredth prime number.

##### Note: The first prime number is 2.
