### Nested loops and conditionals
***

The usefulness of coding can be appreciated when loops and conditionals are combined in the same code.

The adjacent showcases a simple use where a 34 by 6 rectangle is printed in the console without using 34 print statements.