public class TheForLoop
{
   public static void main(String[] args)
   {
      System.out.println("I'm going to print Java 10 times.");
      System.out.println("Ready?");
      for (int counter = 1; counter <= 10; counter++)
      {
         System.out.println(counter + " Java");
      }
      System.out.println("That was fast!");
   }
}