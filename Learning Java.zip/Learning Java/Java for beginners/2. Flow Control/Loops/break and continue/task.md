### *break* and *continue*
***

Sometimes it is necessary or convenient to end a loop prematurely or skip an iteration of the loop and proceed to the next iteration.
It can be accomplished by placing the keywords *break* or *continue*, respectively.

Logically, both statements must be placed inside a conditional. Otherwise, the loop would never repeat, or it would always skip some part.

Beside this window there's an application of these keywords.