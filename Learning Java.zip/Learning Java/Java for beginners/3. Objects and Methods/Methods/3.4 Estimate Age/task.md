## Exercise 3.4
***

#### Complete the instance method epitaph() that prints on the console the message *"\<name> lived to an age of \<age>"*.