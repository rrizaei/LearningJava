## Exercise 3.5
***

The Meal class is a template for objects that contain the name
of a plate along with its price.
There's an option to make it a combo meal, the name is now appended
" with fries and soda" and the cost of the meal is increased by 3.

Code the method makeItACombo that takes no argument but
modifies the objects attributes as described.

Code also the method getBill that needs no input but returns a
String containing the (current) name of the Meal object and its
price.

For example, if a Meal object is created with the values
of name "Burguer" and cost 6.99; after using the makeItACombo
method, the getBill method should return Burguer with fries and soda, $9.99

#### Complete the class.