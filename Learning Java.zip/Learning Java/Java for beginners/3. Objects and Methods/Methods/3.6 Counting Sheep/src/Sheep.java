public class Sheep
{
    static int count; //don't set as private for internal reasons

    //code the constructor so that every time a Sheep is instantiated, it adds 1 to the count
    /* Add 1 to the Sheep count everytime one is created. */
}