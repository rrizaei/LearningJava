## Exercise 3.6
***

#### Complete the code. Keep the count of Sheep created.
