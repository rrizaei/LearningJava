### Returning values
***

It is commonplace to code a method that does some calculation and
then gives you (returns you) that value.
In that case, you **must** know beforehand what **type** of data you expect to get and
place it in the \<return type> part of the method's definition instead of *void*.

Hopefully this code will help you understand that.