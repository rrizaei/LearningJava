public class Thing
{
   public Thing() {}
}