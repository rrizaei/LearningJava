## Exercise 3.1
***

#### Which is the correct way to create a *Thing* object?

<div class="hint">
  When a type of object is specified, that word becomes unusable as an identifier.
</div>