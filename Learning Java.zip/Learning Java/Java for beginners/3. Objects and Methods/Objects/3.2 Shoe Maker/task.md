## Exercise 3.2
***

#### Complete the code.