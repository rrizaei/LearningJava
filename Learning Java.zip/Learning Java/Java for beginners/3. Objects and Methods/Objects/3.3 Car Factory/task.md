## Exercise 3.3
***

#### Which of these statements correctly creates a new car?