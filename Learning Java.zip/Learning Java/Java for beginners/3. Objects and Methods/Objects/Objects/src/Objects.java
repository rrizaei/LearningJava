public class Objects
{
   public static void main(String[] args)
   {
      //Since the name of the class is "Objects", that is the type of objects of this class.
      //Declaring the object.
      Objects myObject1;
      //Now we have to actually create the object and assign it.
      myObject1 = new Objects();

      //Let's make another one, but this one in one line.
      Objects myObject2 = new Objects();
   }
}
