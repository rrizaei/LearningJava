## Exercise 4.3
***

This class should contain a method that takes a *String* as input
and returns a list of its letters (*String*s also, not *char*s).



#### Code the getLettersList method.

<div class="hint">
  You don't need objects here...
</div>

<div class="hint">
  Don't forget to return the appropriate type: String[], not String.
</div>