### The enhanced *for* loop
***

In version 5.0, Java introduced a short way to loop
through arrays: a special version of the *for* loop.

The syntax is fairly simple:

`for (<data_type> <element_name>: <array_name>)`

Such enhanced `for` loop is shown on the left.