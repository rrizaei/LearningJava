## Exercise 4.1
***

The following class contains only one method that takes two
String inputs and return the shortest of both. If both words are the same
length, it may return any of them.

#### Code the method getShortestWord.

<div class="hint">
  Since you don't require any object here, the method should be static.
</div>