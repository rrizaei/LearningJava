## Exercise 4.2
***

The class here contains a method called cutInHalf that takes as input one word
and returns the first half of that word.

#### Code the cutInHalf method.

<div class="hint">
  You don't need objects here, so it should be a static method.
</div>

<div class="hint">
  Use the .length() method.
</div>