public class Length
{
   public static void main(String[] args)
   {
      String word1 = "word";
      String word2 = "word2";

      System.out.println(word1.length());
      System.out.println(word2.repeat(3));
      System.out.println(word2.repeat(3).length());
   }
}