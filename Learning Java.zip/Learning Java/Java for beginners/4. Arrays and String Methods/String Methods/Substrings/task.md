### Substrings
***

A String method that deserves attention is the substring.

That method takes two integer inputs called 'indexes'
and returns the part of the string
that begins with the letter in the first index and until
the letter with index **just before** the second input.

It gets trickier. A standard in programming languages is start by
counting with zero. Therefore, **the first letter of a String is
treated as having index 0**.

Hopefully the examples on the left can shed some light on this.