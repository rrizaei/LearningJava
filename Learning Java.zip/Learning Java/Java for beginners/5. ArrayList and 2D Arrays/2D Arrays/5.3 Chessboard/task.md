## Exercise 5.3

***

Congratulations on finishing the course! I hope you liked it ☻

As the last activity, print an 8x8 chessboard.

To complete this task, use 2D arrays, loops, and the Unicode 
characters for black and white squares, which are
`'\u25A0'` and `'\u25A1'`, respectively.

#### Note: The top left square should be white.

#### Note 2: If you want your chessboard to look better, after you complete the task you can print a space in between squares.

#### Note 3: If you have a dark theme (like Darcula) the colors invert, so the white squares appear black and viceversa. Just revert the colors and you're set with the course!