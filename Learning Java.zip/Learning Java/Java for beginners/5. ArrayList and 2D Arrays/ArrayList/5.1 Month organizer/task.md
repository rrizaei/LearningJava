## Exercise 5.1

***

The ArrayList *months* stores the months of every year in 
chronological order, from January to December.

To complete it, the following lines will be added at the end
(after December is appended).


1. months.add(2, "March");
2. months.add(5, "September");
3. months.add(6, "August");
4. months.add(2, "April");

#### In which order should the previous lines appear?
