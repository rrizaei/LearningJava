## Exercise 5.2

***

Code a method that returns the average (with decimal digits)
of an ArrayList of integers.
